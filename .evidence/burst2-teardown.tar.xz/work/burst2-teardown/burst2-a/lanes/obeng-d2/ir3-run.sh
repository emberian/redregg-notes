cd /srv/lanes/obeng-d2/src
for j in objective-send-native-journey objective-call-native-journey objectrecord-native-journey; do python3 native/resource-client/$j.py --bin ../irbin2 --root ../ir3-$j-$$ > ../logs/ir3-$j.out 2>&1; echo RC=$? >> ../logs/ir3-$j.out; done
echo ALLDONE > ../logs/ir3-done
