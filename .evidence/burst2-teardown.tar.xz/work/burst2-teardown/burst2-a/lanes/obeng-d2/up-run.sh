cd /srv/lanes/obeng-d2/src
/srv/pipeline/scripts/lake-slot minidregg-host minidregg-client-consent minidregg-client-consent-specialized > ../logs/up-exe.log 2>&1 || { echo EXEFAIL > ../logs/up-done; exit 1; }
for e in minidregg-host minidregg-client-consent minidregg-client-consent-specialized; do cp .lake/build/bin/$e ../upbin/; done
python3 native/resource-client/objective-upgrade-native-journey.py --bin ../upbin --root ../up-u-$$ > ../logs/up-upgrade.out 2>&1; echo RC=$? >> ../logs/up-upgrade.out
python3 native/resource-client/objective-domain-native-journey.py --bin ../upbin --root ../up-d-$$ > ../logs/up-domain.out 2>&1; echo RC=$? >> ../logs/up-domain.out
echo ALLDONE > ../logs/up-done
