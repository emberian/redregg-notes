cd /srv/lanes/obeng-d2/src
for p in cancel-bare short-chain roomy-allowance; do python3 native/resource-client/objective-send-native-journey.py --bin ../irbin2 --root ../ir5-$p-$$ --plant $p > ../logs/ir5-plant-$p.out 2>&1; echo RC=$? >> ../logs/ir5-plant-$p.out; done
echo ALLDONE > ../logs/ir5-done
