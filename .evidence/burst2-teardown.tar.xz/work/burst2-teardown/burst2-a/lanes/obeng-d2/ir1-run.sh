set -x
cd /srv/lanes/obeng-d2/src
/srv/pipeline/scripts/lake-slot minidregg-host minidregg-client-consent minidregg-client-consent-specialized > ../logs/ir1-exe.log 2>&1 || { echo EXEFAIL; exit 1; }
for e in minidregg-host minidregg-client-consent minidregg-client-consent-specialized; do cp .lake/build/bin/$e ../irbin/; done
python3 native/resource-client/objective-send-native-journey.py --bin ../irbin --root ../ir1-s-$$ > ../logs/ir1-send.out 2>&1; echo SEND_RC=$? >> ../logs/ir1-send.out
python3 native/resource-client/objective-call-native-journey.py --bin ../irbin --root ../ir1-c-$$ > ../logs/ir1-call.out 2>&1; echo CALL_RC=$? >> ../logs/ir1-call.out
echo ALLDONE
