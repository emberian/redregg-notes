cd /srv/lanes/obeng-d2/src
/srv/pipeline/scripts/lake-slot Kernel Host ObjectiveProofs minidregg-host minidregg-client-consent minidregg-client-consent-specialized > ../logs/ir2-build.log 2>&1; echo RC=$? >> ../logs/ir2-build.log
