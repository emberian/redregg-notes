cd /srv/lanes/obeng-d2/src
/srv/pipeline/scripts/lake-slot minidregg-host minidregg-client-consent minidregg-client-consent-specialized > ../logs/ir4-exe.log 2>&1 || { echo EXEFAIL > ../logs/ir4-done; exit 1; }
for e in minidregg-host minidregg-client-consent minidregg-client-consent-specialized; do rm -f ../irbin2/$e; cp .lake/build/bin/$e ../irbin2/; done
python3 native/resource-client/objective-send-native-journey.py --bin ../irbin2 --root ../ir4-s-$$ > ../logs/ir4-send.out 2>&1; echo RC=$? >> ../logs/ir4-send.out
echo ALLDONE > ../logs/ir4-done
