#!/usr/bin/env bash
# runrow.sh ROW [ENV=VAL...] : run one journey row the way journey-runner does (same variables), evidence in $L/rows/<ROW>[-tag]
L=/srv/lanes/P3-JOURNEYS; T=1dead71744bd528617a5fe38de032ca7a468db02; row=$1; shift
tag=${TAG:-}; O=$L/rows/$row$tag; rm -rf $O; mkdir -p $O; R=$(mktemp -d /tmp/pj.XXXXXX)
export SRC=$L/src SET=$L/art/$T BIN=$L/art/$T/bin MANIFEST=$L/art/$T/manifest.json RUN=$R OUT=$O LEANENV=1
. $SRC/scripts/pipeline/journey-rows
s=$(date +%s); (cd $R && "row_$row") >$O/row.out 2>$O/row.err; rc=$?
echo "row=$row$tag rc=$rc wall=$(( $(date +%s)-s ))s detail=$(tail -n1 $O/row.err | cut -c1-250)"; [ -f $O/subrows.tsv ] && cut -c1-110 $O/subrows.tsv
rm -rf $R
