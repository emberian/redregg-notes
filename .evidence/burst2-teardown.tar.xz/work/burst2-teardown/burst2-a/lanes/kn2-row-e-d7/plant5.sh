L=/srv/lanes/kn2-row-e-d7
rm -rf $L/binplant; mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip-bins/*; do ln -sf $f .; done
rm -f minidregg-host minidregg-client-consent; cp $L/artifacts-planthost/minidregg-host .; cp $L/artifacts/minidregg-client-consent .
sha256sum minidregg-host minidregg-client-consent $L/tip-bins/minidregg-host $L/tip-bins/minidregg-client-consent
rm -rf $L/j/native-plant; python3 $L/src/native/resource-client/objective-native-acceptance.py all --bin $L/binplant --root $L/j/native-plant > $L/j/native-plant.log 2>&1; echo "EXIT $?" >> $L/j/native-plant.log
echo PLANTDONE >> $L/j/native-plant.log
