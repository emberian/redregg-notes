L=/srv/lanes/kn2-row-e-d7; export LANE_DIR=$L; cd $L/src
mv $L/artifacts $L/artifacts-planthost; mkdir -p $L/artifacts
for i in $(seq 1 60); do
  /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh consent > $L/logs/plant-consent.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/plant-consent.log
  [ $rc -eq 75 ] || break; mv $L/consent-out $L/consent-out-pr$i; sleep 60
done
grep -q "^EXIT 0" $L/logs/plant-consent.log || exit 1
ls $L/artifacts
rm -rf $L/binplant; mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip-bins/*; do ln -sf $f .; done
rm -f minidregg-host minidregg-client-consent; cp $L/artifacts-planthost/minidregg-host .; cp $L/artifacts/minidregg-client-consent .
sha256sum minidregg-host minidregg-client-consent $L/tip-bins/minidregg-host $L/tip-bins/minidregg-client-consent
rm -rf $L/j/native-plant; python3 $L/src/native/resource-client/objective-native-acceptance.py all --bin $L/binplant --root $L/j/native-plant > $L/j/native-plant.log 2>&1; echo "EXIT $?" >> $L/j/native-plant.log
echo PLANTDONE >> $L/j/native-plant.log
