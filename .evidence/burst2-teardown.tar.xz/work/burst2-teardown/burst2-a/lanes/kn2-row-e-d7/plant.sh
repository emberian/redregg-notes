L=/srv/lanes/kn2-row-e-d7
cd $L/src
git checkout -q -f -B plant-d7 lane/kn2-row-e-d7
python3 - <<"PY"
p="Kernel/ObjectiveBendNativeAdmission.lean"
s=open(p).read()
a="""                    match work : ObjectiveWorkAccount.uncovered package.package loaded.artifact claim.capacity with
                    | some (stage, needed, declared) => .error (.objectiveWork stage needed declared)
                    | none =>"""
assert s.count(a)==1
s=s.replace(a,"""                    match work : (none : Option (ObjectiveWorkAccount.Stage × Nat × Nat)) with
                    | some (stage, needed, declared) => .error (.objectiveWork stage needed declared)
                    | none =>""")
s=s.replace("""  workCovered : ObjectiveWorkAccount.uncovered package.package loaded.artifact claim.capacity = none""","""  workCovered : (none : Option (ObjectiveWorkAccount.Stage × Nat × Nat)) = none""")
i=s.index("theorem SourceSelection.frontEnd_declared"); j=s.index("private def checkedFunding")
s=s[:s.rfind("/--",0,i)]+s[j:]
open(p,"w").write(s)
PY
git -c commit.gpgsign=false -c user.name=plant -c user.email=plant@x commit -qam "PLANT: the native route does not compare the claim with the front end"
mkdir -p $L/tip-bins; cp -a $L/artifacts/. $L/tip-bins/; mv $L/native-out $L/native-out-tip; mv $L/consent-out $L/consent-out-tip 2>/dev/null; mv $L/cycle $L/cycle-tip 2>/dev/null
for i in $(seq 1 60); do
  /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh host --umbrella --umbrella-target Host.Main > $L/logs/plant-host.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/plant-host.log
  [ $rc -eq 75 ] || break; mv $L/native-out $L/native-out-pr$i; sleep 60
done
mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip-bins/*; do ln -sf $f .; done; rm -f minidregg-host; cp $L/artifacts/minidregg-host .
rm -rf $L/j/native-plant; python3 $L/src/native/resource-client/objective-native-acceptance.py all --bin $L/binplant --root $L/j/native-plant > $L/j/native-plant.log 2>&1; echo "EXIT $?" >> $L/j/native-plant.log
echo PLANTDONE >> $L/j/native-plant.log
