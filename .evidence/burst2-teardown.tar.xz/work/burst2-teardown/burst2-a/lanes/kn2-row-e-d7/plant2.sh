L=/srv/lanes/kn2-row-e-d7; export LANE_DIR=$L; cd $L/src
for i in $(seq 1 60); do
  /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh host --umbrella --umbrella-target Host.Main > $L/logs/plant-host.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/plant-host.log
  [ $rc -eq 75 ] || break; mv $L/native-out $L/native-out-pr$i; sleep 60
done
grep -q "^EXIT 0" $L/logs/plant-host.log || exit 1
rm -rf $L/binplant; mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip-bins/*; do ln -sf $f .; done; rm -f minidregg-host; cp $L/artifacts/minidregg-host .
rm -rf $L/j/native-plant; python3 $L/src/native/resource-client/objective-native-acceptance.py all --bin $L/binplant --root $L/j/native-plant > $L/j/native-plant.log 2>&1; echo "EXIT $?" >> $L/j/native-plant.log
echo PLANTDONE >> $L/j/native-plant.log
