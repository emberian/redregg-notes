L=/srv/lanes/kn2-row-e-d7; cd $L/src; export LANE_DIR=$L
bash -l $L/exe.sh; grep -q "^EXIT 0" $L/logs/exe-roots.log || { echo EXE-ROOTS RED; exit 1; }
for step in host consent; do
  for i in $(seq 1 60); do
    if [ $step = host ]; then args="host --umbrella --umbrella-target Host.Main"; out=native-out; else args=consent; out=consent-out; fi
    /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh $args > $L/logs/$step.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/$step.log
    [ $rc -eq 75 ] || break
    mv $L/$out $L/$out-r$i-$$; sleep 60
  done
  grep -q "^EXIT 0" $L/logs/$step.log || exit 1
done
/srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh rust > $L/logs/rust.log 2>&1; echo EXIT $? >> $L/logs/rust.log
grep -q "^EXIT 0" $L/logs/rust.log || exit 1
mkdir -p $L/j; rm -rf $L/j/native; python3 $L/src/native/resource-client/objective-native-acceptance.py all --bin $L/artifacts --root $L/j/native > $L/j/native.log 2>&1; echo "native EXIT $?" >> $L/j/native.log
echo PIPELINEDONE >> $L/logs/exe-roots.log
