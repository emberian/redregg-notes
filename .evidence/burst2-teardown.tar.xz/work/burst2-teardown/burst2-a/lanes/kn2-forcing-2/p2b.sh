#!/bin/bash -l
cd /srv/lanes/kn2-forcing-2/src
export LEAN_NUM_THREADS=4 SWARM_MEM_MAX=32G
L=/srv/lanes/kn2-forcing-2/logs
run() { flock -n /srv/build-slot-2 "$@" || flock -n /srv/build-slot-3 "$@" || flock /srv/build-slot-4 "$@"; }
run swarm-build lake build AxiomCensusResearch > $L/research-build.log 2>&1; echo "RESEARCH_RC=$?" >> $L/p2.status
run swarm-build bash scripts/check-hypothesis-ledger.sh > $L/ledger-01.log 2>&1; echo "LEDGER_RC=$?" >> $L/p2.status
