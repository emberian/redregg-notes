#!/bin/bash -l
cd /srv/lanes/kn2-forcing-2/src
export LEAN_NUM_THREADS=4 SWARM_MEM_MAX=32G
L=/srv/lanes/kn2-forcing-2/logs
run() { flock -n /srv/build-slot-2 "$@" || flock -n /srv/build-slot-3 "$@" || flock /srv/build-slot-4 "$@"; }
for p in absolute nocheck otheryield; do
  python3 ../plants.py $p && git diff --stat >> $L/plant-$p.log
  run swarm-build lake build Kernel.ObjectiveResumeContract >> $L/plant-$p.log 2>&1; echo "PLANT_$p RC=$?" >> $L/p2.status
  git checkout -- Kernel/ObjectiveActivity.lean
done
run swarm-build lake build Kernel.ObjectiveResumeContract Kernel.ObjectiveCheckpointInvariant ObjectiveProofs Theory.ObjectiveBendLedgerPoles > $L/build-04.log 2>&1; echo "RESTORED RC=$?" >> $L/p2.status
run swarm-build bash scripts/check-objective-proofs.sh proofs --update > $L/proofs-update.log 2>&1; echo "PROOFS_RC=$?" >> $L/p2.status
run swarm-build bash scripts/check-objective-proofs.sh transparency > $L/transparency-01.log 2>&1; echo "TRANSP_RC=$?" >> $L/p2.status
