#!/bin/bash -l
cd /srv/lanes/kn2-forcing-2/src
export LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G
N=${1:-01}; shift
run() { flock -n /srv/build-slot-2 "$@" || flock -n /srv/build-slot-3 "$@" || flock /srv/build-slot-4 "$@"; }
run swarm-build lake build "$@" > /srv/lanes/kn2-forcing-2/logs/build-$N.log 2>&1
echo "RC=$?" >> /srv/lanes/kn2-forcing-2/logs/build-$N.log
