source /srv/pipeline/box.env
export PATH=$HOME/.elan/bin:$HOME/.cargo/bin:$PATH
A=/srv/artifacts/cfdaf64df8f869f5e45c86a85055457345fc5ae1/bin
ST=$A/minidregg-link-sqlite-store
L=/srv/lanes/census-pl-B/logs; cd /srv/lanes/census-pl-B/src
: > $L/probes2.summary
for f in scripts/probe-*.lean; do n=$(basename $f .lean)
  case $n in probe-canonical-cell-registry|probe-policy-source-cell) args="$ST";; *) args="";; esac
  timeout 900 lake env lean --run $f $args > $L/$n.log 2>&1; echo "$n rc=$? :: $(tail -n1 $L/$n.log|cut -c1-170)" >> $L/probes2.summary
done
echo DONE >> $L/probes2.summary
