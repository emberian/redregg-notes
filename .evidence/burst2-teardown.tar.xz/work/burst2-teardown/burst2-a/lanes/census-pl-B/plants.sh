source /srv/pipeline/box.env
export PATH=$HOME/.elan/bin:$HOME/.cargo/bin:$PATH
A=/srv/artifacts/cfdaf64df8f869f5e45c86a85055457345fc5ae1/bin
V=$A/minidregg-credential-signature-verifier; ST=$A/minidregg-link-sqlite-store
SG=/srv/lanes/census-pl-B/rust-target/release/examples/sign-probe
L=/srv/lanes/census-pl-B/logs; cd /srv/lanes/census-pl-B/src
S=$L/plants.summary; : > $S
st(){ echo "git-status-after-$1: [$(git status --porcelain --untracked-files=no | tr '\n' ' ')]" >> $S; }
bash scripts/kn2/plant-neutral-birth.sh $V $SG $ST $L > $L/run-plant-nb.log 2>&1; echo "nb rc=$?" >> $S; cat $L/run-plant-nb.log >> $S; st nb
bash scripts/kn2/plant-neutral-birth-install.sh $V $SG $ST $L > $L/run-plant-install.log 2>&1; echo "install rc=$?" >> $S; cat $L/run-plant-install.log >> $S; st install
bash scripts/kn2/plant-neutral-birth-reserve.sh $V $SG $ST $L > $L/run-plant-reserve.log 2>&1; echo "reserve rc=$?" >> $S; cat $L/run-plant-reserve.log >> $S; st reserve
bash scripts/kn2/plant-grain-neutral-birth.sh $A $L > $L/run-plant-grain.log 2>&1; echo "grain rc=$?" >> $S; cat $L/run-plant-grain.log >> $S; st grain
echo DONE >> $S
