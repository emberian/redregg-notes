source /srv/pipeline/box.env
export PATH=$HOME/.elan/bin:$HOME/.cargo/bin:$PATH
A=/srv/artifacts/cfdaf64df8f869f5e45c86a85055457345fc5ae1/bin
V=$A/minidregg-credential-signature-verifier; ST=$A/minidregg-link-sqlite-store
SG=/srv/lanes/census-pl-B/rust-target/release/examples/sign-probe
L=/srv/lanes/census-pl-B/logs; cd /srv/lanes/census-pl-B/src
r(){ n=$1; shift; timeout 1500 "$@" > $L/probe-$n.log 2>&1; echo "$n rc=$? :: $(tail -n1 $L/probe-$n.log|cut -c1-160)" >> $L/probes.summary; }
: > $L/probes.summary
r coprocess lake env lean --run scripts/kn2/coprocess-faults.lean $V
for p in history-tamper index-tamper port-b-tamper port-b-undeclared receipt-tamper authority-undeclared scratch-reader; do r $p lake env lean --run scripts/kn2/$p.lean $ST; done
r invoke-undeclared lake env lean --run scripts/kn2/invoke-undeclared.lean $ST $V
r nb-all lake env lean --run scripts/kn2/neutral-birth.lean $V $SG $ST
r nb-control lake env lean --run scripts/kn2/neutral-birth.lean $V $SG $ST control
r nb-install lake env lean --run scripts/kn2/neutral-birth-install.lean $V $SG $ST
r nb-reserve-all lake env lean --run scripts/kn2/neutral-birth-reserve.lean $V $SG $ST
r nb-reserve-control lake env lean --run scripts/kn2/neutral-birth-reserve.lean $V $SG $ST control
echo DONE >> $L/probes.summary
