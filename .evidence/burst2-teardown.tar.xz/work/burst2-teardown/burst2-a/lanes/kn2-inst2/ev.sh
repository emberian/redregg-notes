#!/bin/bash
# install evidence on the rebased tip: plant, exe roots, journeys
L=/srv/lanes/kn2-inst2; cd $L/src; . /srv/pipeline/box.env; umask 022
timeout 900 lake env lean --run scripts/kn2/authority-undeclared.lean /srv/lanes/kn2-so2/store-helper > $L/logs/authority-undeclared.log 2>&1; echo "plant rc=$?" >> $L/logs/ev.status
scripts/ports/check-full-loaded-callers.sh > $L/logs/ratchet.log 2>&1; echo "ratchet rc=$?" >> $L/logs/ev.status
/srv/pipeline/scripts/lake-slot $(sed -n "/^\[\[lean_exe\]\]/{n;s/^name *= *\"\(.*\)\"$/\1/p}" lakefile.toml) > $L/logs/exe-roots.log 2>&1; echo "exe-roots rc=$?" >> $L/logs/ev.status
rm -rf $L/art; /srv/pipeline/scripts/fetch-artifacts b86c7f1af45eca60cfe2441ecb627ece344cc686 $L/art --link > $L/logs/fetch.log 2>&1
chmod u+w $L/art/bin $L/art/manifest.json
for b in minidregg-host minidregg-client-consent; do rm -f $L/art/bin/$b; cp .lake/build/bin/$b $L/art/bin/$b; done
H=$(sha256sum $L/art/bin/minidregg-host|cut -d" " -f1); C=$(sha256sum $L/art/bin/minidregg-client-consent|cut -d" " -f1)
jq --arg h $H --arg c $C ".sha256.host=\$h | .sha256.consent=\$c | .sha256.consentHost=\$c" $L/art/manifest.json > /tmp/kn2i2m.json && mv /tmp/kn2i2m.json $L/art/manifest.json
echo "manifest host=$(jq -r .host $L/art/manifest.json) sha=$H" >> $L/logs/ev.status
R=/run/user/$(id -u)/kn2i2; rm -rf $R; mkdir -p $R
JOURNEY_STEPS="J0 J1 J2 J3 J4 J5 J6 J7 J8 JPRIV1" bash native/resource-client/journey.sh $L/art/manifest.json $R/j > $L/logs/journey.out 2> $L/logs/journey.err; echo "journey rc=$?" >> $L/logs/ev.status
echo DONE >> $L/logs/ev.status
