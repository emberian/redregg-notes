#!/usr/bin/env bash
cd /srv/lanes/h-manifest-b13/src && source ~/.profile
L=../logs
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs --pin > $L/b13-pin.log 2>&1; echo "EXIT $?" >> $L/b13-pin.log
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs > $L/b13-final.log 2>&1; echo "EXIT $?" >> $L/b13-final.log
echo ALLDONE >> $L/b13-final.log
