#!/usr/bin/env bash
cd /srv/lanes/h-manifest-b13/src && source ~/.profile
L=../logs
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs --draft 10e4f3ab..8ebbdf9b > $L/b13-draft2.log 2>&1; echo "EXIT $?" >> $L/b13-draft2.log
cp build-logs/objective/draft-ledger.txt build-logs/objective/draft-review.txt $L/ 2>/dev/null
echo ALLDONE >> $L/b13-draft2.log
