L=/srv/lanes/kn2-row-e7; cd $L/src; export LANE_DIR=$L
export PIPELINE_LAKE_CACHE=/srv/lanes/kn2-row-e7/private-lake-cache
bash -l $L/exe.sh; grep -q "^EXIT 0" $L/logs/exe-roots.log || echo "EXE-ROOTS RED (continuing)" >> $L/logs/exe-roots.log
for step in host consent; do
  for i in $(seq 1 60); do
    if [ $step = host ]; then args="host --umbrella --umbrella-target Host.Main"; out=native-out; else args=consent; out=consent-out; fi
    /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh $args > $L/logs/$step.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/$step.log
    [ $rc -eq 75 ] || break
    mv $L/$out $L/$out-r$i-$$; sleep 60
  done
  grep -q "^EXIT 0" $L/logs/$step.log || exit 1
done
/srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh rust > $L/logs/rust.log 2>&1; echo EXIT $? >> $L/logs/rust.log
grep -q "^EXIT 0" $L/logs/rust.log || exit 1
mkdir -p $L/j; bash $L/journeys.sh
bash -l $L/plants-r2.sh > $L/logs/plants.out 2>&1; bash -l $L/plants-r2b.sh >> $L/logs/plants.out 2>&1
echo PIPELINEDONE >> $L/logs/plants.out
# the S22 retry plant: the same tip with verifyRetry over the re-planned outcome
cd $L/src && git checkout -q -f -B plant-retry lane/kn2-row-e-2-next && python3 - <<"PY"
p="Kernel/ObjectiveActivityReceiver.lean"
s=open(p).read()
a="""  let ⟨_, request⟩ := signedRequest authority.snapshot profile.semantics ambient command preRoot
    ingress.ingress.outcome"""
assert s.count(a)==1
s=s.replace(a,"""  let ⟨_, request⟩ := signedRequest authority.snapshot profile.semantics ambient command preRoot
    (planOutcome deployment profile ambient durable command)""")
open(p,"w").write(s)
PY
git -c commit.gpgsign=false -c user.name=plant -c user.email=plant@x commit -qam "PLANT: verifyRetry over the re-planned outcome"
mkdir -p $L/tip-bins; mv $L/artifacts/* $L/tip-bins/; mv $L/native-out $L/native-out-tip; mv $L/consent-out $L/consent-out-tip; mv $L/cycle $L/cycle-tip
/srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh host --umbrella --umbrella-target Host.Main > $L/logs/plant-host.log 2>&1; echo EXIT $? >> $L/logs/plant-host.log
mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip-bins/*; do ln -sf $f .; done; rm -f minidregg-host; cp $L/artifacts/minidregg-host .
rm -rf $L/j-plant-send; python3 $L/src/native/resource-client/objective-send-native-journey.py --bin $L/binplant --root $L/j-plant-send > $L/logs/plant-send.log 2>&1; echo "EXIT $?" >> $L/logs/plant-send.log
echo ALLEVIDENCE >> $L/logs/plants.out
