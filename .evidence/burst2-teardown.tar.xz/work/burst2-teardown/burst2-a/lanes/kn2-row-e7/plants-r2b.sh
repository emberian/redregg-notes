#!/bin/bash
export PIPELINE_LAKE_CACHE=/srv/lanes/kn2-row-e7/private-lake-cache
cd /srv/lanes/kn2-row-e7/src || exit 2
OUT=/srv/lanes/kn2-row-e7/logs/plants-r2; mkdir -p $OUT
python3 - <<'PY'
p='Kernel/ObjectiveTariff.lean'
s=open(p).read()
a="  t.version == tariffVersion && decide (0 < t.base) && decide (0 < t.replayBytes) && decide (0 < t.coreBytes)"
assert s.count(a)==1
s=s.replace(a,"  t.version == tariffVersion && decide (0 < t.base) && decide (0 < t.replayBytes)")
open(p,'w').write(s)
PY
git diff > $OUT/P8-deployed-tariff-core-rate-zero.diff
/srv/pipeline/scripts/lane-check Kernel/ObjectiveTariff.lean > $OUT/P8-deployed-tariff-core-rate-zero.log 2>&1; rc=$?
git checkout -- Kernel/ObjectiveTariff.lean
echo "P8-deployed-tariff-core-rate-zero rc=$rc errors=$(grep -c error $OUT/P8-deployed-tariff-core-rate-zero.log); $(grep -m2 error $OUT/P8-deployed-tariff-core-rate-zero.log | cut -c1-200 | tr '\n' ' ')"
