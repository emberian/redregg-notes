cd /srv/lanes/kn2-row-e7/src
export PIPELINE_LAKE_CACHE=/srv/lanes/kn2-row-e7/private-lake-cache
/srv/pipeline/scripts/lake-slot minidregg-host minidregg-client-consent minidregg-client-consent-specialized world-fold-bench world-root-bench kn2-store-bench nock-eval objective-cdiff objective-cdiff-gen cshake-bench minidregg-carry-verifier generic-simplex-harness generic-simplex-log-reopen minidregg-four-source-fixture generic-simplex-load  Host.Main ObjectiveProofs Kernel Kernel.ObjectiveActivityGateRoute Kernel.ObjectiveUpgradeInvariant Compiler.ObjectiveBendC4Vectors > /srv/lanes/kn2-row-e7/logs/exe-roots.log 2>&1
echo EXIT $? >> /srv/lanes/kn2-row-e7/logs/exe-roots.log
