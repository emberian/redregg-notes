#!/bin/bash
export PIPELINE_LAKE_CACHE=/srv/lanes/kn2-row-e7/private-lake-cache
# Range-2 planted faults: each edit must turn a named theorem red; the tree is restored after each.
cd /srv/lanes/kn2-row-e7/src || exit 2
OUT=/srv/lanes/kn2-row-e7/logs/plants-r2
mkdir -p $OUT
plant() {  # NAME FILE CHECKFILE OLD NEW
  name=$1; file=$2; check=$3; old=$4; new=$5
  python3 - "$file" "$old" "$new" <<'PY'
import sys
p,a,b=sys.argv[1:4]
s=open(p).read()
assert s.count(a)>=1,("plant anchor missing",a)
open(p,'w').write(s.replace(a,b,1))
PY
  git diff > $OUT/$name.diff
  /srv/pipeline/scripts/lane-check $check > $OUT/$name.log 2>&1; rc=$?
  git checkout -- $file
  echo "$name rc=$rc errors=$(grep -c 'error' $OUT/$name.log); $(grep -m2 'error' $OUT/$name.log | cut -c1-200 | tr '\n' ' ')"
}
plant P5-failure-keeps-a-business-write Kernel/ObjectiveActivity.lean Kernel/ObjectiveActivityReceiver.lean \
  "  [charged.posted.write config snapshot]" "  [charged.posted.write config snapshot, postAt snapshot ⟨0⟩ []]"
plant P6-malformed-path-charges Kernel/ObjectiveActivityReceiver.lean Kernel/ObjectiveActivityReceiver.lean \
  "    | return .rejected .malformedIngress" "    | return .charged .installed ⟨⟨0⟩, ⟨0⟩⟩ .malformedIngress"
plant P6b-decision-before-gate Kernel/ObjectiveActivityReceiver.lean Kernel/ObjectiveActivityReceiver.lean \
  "  match gate deployment profile ambient durable ingress.command ingress.ingress.outcome with
  | .error reason => return .error reason" "  match gate deployment profile ambient durable ingress.command ingress.ingress.outcome with
  | .error reason => do
    IO.println \"decided anyway\"
    return .error reason"
# P7: the gate without the funds check (the field and the check both removed: anything less does not typecheck)
python3 - <<'PY'
p='Kernel/ObjectiveActivityReceiver.lean'
s=open(p).read()
s=s.replace("  funded : funding config durable command = .ok ()\n","",1)
s=s.replace("""      match funded : funding config durable command with
      | .error reason => throw reason
      | .ok () => pure ⟨directory, authority, config, configExact, preRoot, rfl, authorizedExact, funded⟩""","""      pure ⟨directory, authority, config, configExact, preRoot, rfl, authorizedExact⟩""",1)
open(p,'w').write(s)
PY
git diff > $OUT/P7-gate-without-funds.diff
/srv/pipeline/scripts/lane-check Kernel/ObjectiveActivityReceiver.lean > $OUT/P7-gate-without-funds.log 2>&1; rc=$?
git checkout -- Kernel/ObjectiveActivityReceiver.lean
echo "P7-gate-without-funds rc=$rc errors=$(grep -c 'error' $OUT/P7-gate-without-funds.log); $(grep -m2 'error' $OUT/P7-gate-without-funds.log | cut -c1-200 | tr '\n' ' ')"
git status --short | grep -v snapshot
