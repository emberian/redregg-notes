#!/bin/bash
# usage: b.sh LOG targets...   (holds one lane slot on burst2-b; foreground; waits for ANY free slot)
log=$1; shift
cd /srv/lanes/kn2-so2/src
cmd="LEAN_NUM_THREADS=4 SWARM_MEM_MAX=${MEM:-24G} swarm-build lake build $*"
run() { while :; do for slot in /srv/build-slot-2 /srv/build-slot-3 /srv/build-slot-4; do flock -n -E 75 $slot bash -c "$cmd"; rc=$?; [ $rc -ne 75 ] && return $rc; done; sleep 10; done; }
run > /srv/lanes/kn2-so2/logs/$log 2>&1
echo "EXIT $?" >> /srv/lanes/kn2-so2/logs/$log
