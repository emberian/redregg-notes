#!/bin/bash
L=/srv/lanes/kn2-so2
cd $L/src
$L/b.sh bench-before-build.log kn2-store-bench
cp .lake/build/bin/kn2-store-bench $L/kn2-store-bench-before
( cd /tmp && timeout 7200 $L/kn2-store-bench-before $L/store-helper 300 3000 ) > $L/logs/bench-before.log 2>&1; echo "EXIT $?" >> $L/logs/bench-before.log
cp $L/ii/DurableCheckpointCodec.lean $L/ii/DurableLogTags.lean $L/ii/DurableReceiverIO.lean Compiler/
cp $L/ii/Main.lean Host/; cp $L/ii/DurableCheckpoint.lean Kernel/
$L/b.sh bench-after-build.log kn2-store-bench
cp .lake/build/bin/kn2-store-bench $L/kn2-store-bench-after
( cd /tmp && timeout 7200 $L/kn2-store-bench-after $L/store-helper 300 3000 ) > $L/logs/bench-after.log 2>&1; echo "EXIT $?" >> $L/logs/bench-after.log
echo done > $L/logs/bench.done
