#!/bin/bash
L=/srv/lanes/kn2-so2
cd $L/src
$L/b.sh probes-build.log Compiler.DurableStoreAudit
umask 022
timeout 1800 lake env lean --run scripts/kn2/history-tamper.lean $L/store-helper > $L/logs/tamper-ii.log 2>&1; echo "EXIT $?" >> $L/logs/tamper-ii.log
timeout 1800 lake env lean --run scripts/durable-receiver.lean $L/store-helper > $L/logs/durable-receiver-ii.log 2>&1; echo "EXIT $?" >> $L/logs/durable-receiver-ii.log
echo done > $L/logs/probes.done
