#!/usr/bin/env bash
cd /srv/lanes/census-build/src
. /srv/pipeline/box.env
export PIPELINE_LAKE_CACHE=/srv/lanes/census-build/lake-cache
mkdir -p $PIPELINE_LAKE_CACHE
date -u +%FT%TZ > ../build-start.txt
rm -rf .lake/build
/srv/pipeline/scripts/lake-slot Minidregg Theory Kernel Pred Effects Compiler Selvage Assurance Host AxiomCensus Deployed AxiomCensusResearch TokenCensus Verify SimplexQualification ObjectiveProofs ResearchWip +Host.Main:leanArts > ../build.log 2>&1
echo $? > ../build-exit.txt
date -u +%FT%TZ > ../build-end.txt
