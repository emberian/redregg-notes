cd /srv/lanes/census-pl-C/logs; B=/srv/artifacts/cfdaf64df8f869f5e45c86a85055457345fc5ae1/bin; S=/srv/lanes/census-pl-C/src
run() { ./runj.sh "$@"; }
( for p in honest-thief vault-permit-all gate-open; do run call-$p $S $B objective-call-native-journey.py $p; done ) &
( run domain-member-permit $S $B objective-domain-native-journey.py member-permit; run upgrade-stranger $S $B objective-upgrade-native-journey.py stranger-authority;
  for p in record-present permit-all-law deliverer-passes; do run or-$p $S $B objectrecord-native-journey.py $p; done ) &
( for p in plus-one double-pay raid; do run bounty-$p $S $B objective-bounty-native-acceptance.py $p; done; run ctl-activity $S $B objective-activity-native-acceptance.py ) &
( for p in vault-open dir-empty roomy-postage relay-deposit cancel-late cancel-early; do run send-$p $S $B objective-send-native-journey.py $p; done ) &
( for p in stop-cancels sender-controls bounce-twice roomy-allowance fan-four short-chain cancel-bare fresh-op; do run send-$p $S $B objective-send-native-journey.py $p; done ) &
wait; touch plants.done
