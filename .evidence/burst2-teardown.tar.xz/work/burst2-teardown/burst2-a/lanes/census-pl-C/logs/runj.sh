#!/usr/bin/env bash
# runj.sh LABEL SRCLANE BIN SCRIPT [plant]  -> logs/LABEL.log, appends "LABEL rc lastline" to logs/results.txt
L=$1; SRC=$2; BIN=$3; S=$4; P=${5:-}
LOG=/srv/lanes/census-pl-C/logs; R=$(mktemp -d /tmp/plC.XXXXXX)
cd $SRC
case $S in
 objective-bounty-native-acceptance.py) args=(all --bin $BIN --root $R/w) ;;
 *) args=(--bin $BIN --root $R/w) ;;
esac
[ -n "$P" ] && args+=(--plant "$P")
timeout 3000 python3 native/resource-client/$S "${args[@]}" >$LOG/$L.log 2>&1; rc=$?
cp $R/w/groups.tsv $LOG/$L.groups.tsv 2>/dev/null
echo -e "$L\t$rc\t$(tail -1 $LOG/$L.log | cut -c1-250)" >> $LOG/results.txt
rm -rf $R
