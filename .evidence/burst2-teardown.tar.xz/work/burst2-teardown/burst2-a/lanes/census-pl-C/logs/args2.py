import sys,pathlib
p=pathlib.Path(sys.argv[1])/'Kernel/ObjectiveCall.lean'; s=p.read_text()
for old,new in [('  else if grant.args.admits args = false then .mismatch .args\n','  else if false then .mismatch .args\n'),('  else match grant.args.amount args with\n','  else match (some 0 : Option Nat) with\n')]:
    assert s.count(old)==1; s=s.replace(old,new)
p.write_text(s)
