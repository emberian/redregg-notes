#!/usr/bin/env bash
source /srv/pipeline/box.env
N=$1; L=/srv/lanes/census-pl-C-$N; mkdir -p $L/logs; rm -f $L/logs/hostbuild.rc
cd $L/src; touch .minidregg-native-snapshot
for try in $(seq 1 40); do
  rm -rf $L/native-out $L/consent-out $L/cycle/* $L/artifacts/*
  /srv/pipeline/scripts/slot.sh env SWARM_MEM_MAX=48G swarm-build env LANE_DIR=$L deploy/candidate/lane-build.sh host --umbrella --umbrella-target Host.Main >>$L/logs/hostbuild.log 2>&1
  rc=$?; echo "try $try rc $rc" >>$L/logs/hostbuild.tries
  [ $rc = 75 ] || break
  sleep 90
done
echo $rc >$L/logs/hostbuild.rc
