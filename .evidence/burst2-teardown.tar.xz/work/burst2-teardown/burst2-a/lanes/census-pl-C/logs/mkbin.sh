#!/usr/bin/env bash
# mkbin.sh NAME -> /srv/lanes/census-pl-C/bins/NAME with the planted minidregg-host
N=$1; L=/srv/lanes/census-pl-C-$N; D=/srv/lanes/census-pl-C/bins/$N; SET=/srv/artifacts/cfdaf64df8f869f5e45c86a85055457345fc5ae1/bin
[ "$(cat $L/logs/hostbuild.rc)" = 0 ] || { echo "hostbuild rc $(cat $L/logs/hostbuild.rc)"; exit 1; }
rm -rf $D; mkdir -p $D; for f in $SET/*; do ln -s $f $D/$(basename $f); done
rm $D/minidregg-host; cp $L/artifacts/minidregg-host $D/minidregg-host
cmp -s $D/minidregg-host $SET/minidregg-host && echo "SAME BINARY AS CONTROL" || echo "differs from control: ok"
sha256sum $D/minidregg-host $SET/minidregg-host
