import sys,pathlib,re
p=pathlib.Path(sys.argv[1])/'Kernel/ObjectiveCall.lean'; s=p.read_text()
m=re.search(r'^theorem Grant\.judge_admit\b',s,re.M); start=s.index(':= by',m.start())
end=re.search(r'\n(?=(theorem |def |/--|/-!|#assert|private |@\[|end ))',s[start:]); stop=start+end.start()
s=s[:start]+':= by\n  sorry -- PLANT args-blind-grant (repaired)\n'+s[stop:]
for n in ['Grant.judge_admit','Authorized.spend','exec_delegations','invocation_delegated_authority']:
    assert s.count(f'#assert_axioms {n}\n')==1; s=s.replace(f'#assert_axioms {n}\n','')
p.write_text(s)
