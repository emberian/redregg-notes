#!/usr/bin/env bash
source /srv/pipeline/box.env
N=$1; L=/srv/lanes/census-pl-C-$N; rm -f $L/logs/consent.rc
cd $L/src
for try in $(seq 1 40); do
  rm -rf $L/consent-out; rm -f $L/artifacts/minidregg-client-consent
  /srv/pipeline/scripts/slot.sh env SWARM_MEM_MAX=48G swarm-build env LANE_DIR=$L deploy/candidate/lane-build.sh consent >>$L/logs/consent.log 2>&1
  rc=$?; echo "try $try rc $rc" >>$L/logs/consent.tries
  [ $rc = 75 ] || break
  sleep 90
done
echo $rc >$L/logs/consent.rc
