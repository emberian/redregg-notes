#!/bin/sh
# swap-host.sh BIN TAG: fresh copy of pristine recording, install BIN as minidregg-host, re-pin its sha in every file that carries the recorded sha, run --restart
set -e
L=/srv/lanes/P2-SPK-FIXTURE; P=/run/user/1001/p2fx
OLD=$(sha256sum $L/bin/minidregg-host | cut -c1-64); NEW=$(sha256sum $1 | cut -c1-64)
chmod -R u+rwX $P/rec1 2>/dev/null || :; rm -rf $P/rec1; cp -a $P/rec1.pristine $P/rec1; chmod -R u+rwX $P/rec1
install -m 755 $1 $P/rec1/bin/minidregg-host
grep -rl $OLD $P/rec1 | grep -v /logs/ > $L/logs/swap-$2-pinfiles.txt
for f in $(cat $L/logs/swap-$2-pinfiles.txt); do sed -i "s/$OLD/$NEW/g" $f; done
echo "swap $2: old=$OLD new=$NEW pinfiles=$(wc -l < $L/logs/swap-$2-pinfiles.txt)" > $L/logs/swap-$2.txt
cd $L/src
(umask 077; PATH=$L/tools/bin:$PATH LANE_BIN=$L/bin sh scripts/spk-platform/fixture-v4.sh --restart $P/rec1 > $L/logs/fx-swap-$2.log 2>&1; echo FXEXIT=$? >> $L/logs/fx-swap-$2.log) || :
tail -n 2 $L/logs/fx-swap-$2.log | cut -c1-200
