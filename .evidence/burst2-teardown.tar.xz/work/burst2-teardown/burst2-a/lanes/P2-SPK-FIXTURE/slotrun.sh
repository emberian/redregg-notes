#!/bin/bash
# slotrun.sh CMD...: poll slots 2,3,4 (never 1/mk) and run CMD in the first free one; exit with CMD's status.
while :; do
  for s in 2 3 4; do
    flock -E 75 -n /srv/build-slot-$s "$@"; rc=$?
    [ $rc -ne 75 ] && exit $rc
  done
  sleep 5
done
