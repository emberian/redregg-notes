set -e
for d in resource-client hyperdocument-link-sqlite-store credential-signature-verifier; do
  export CARGO_TARGET_DIR=/srv/lanes/P2-SPK-FIXTURE/rust-target-$d
  (cd /srv/lanes/P2-SPK-FIXTURE/src/native/$d && cargo build --locked 2>&1 | tail -3)
done
