#!/bin/sh
# restart-red.sh MODEFLAG TAG: copy of the pristine recording with the planted-fault spk-host installed and its sha256 re-pinned (only that differs)
set -e
P=/run/user/1001/p2fx; L=/srv/lanes/P2-SPK-FIXTURE
chmod -R u+rwX $P/rec1 2>/dev/null || :; rm -rf $P/rec1; cp -a $P/rec1.pristine $P/rec1
chmod -R u+rwX $P/rec1
install -m 755 $L/bin-red/spk-host $P/rec1/bin/spk-host
for f in $P/rec1/grains/*/host/grain-host.json $P/rec1/fos/broker.json $P/rec1/grains/broker/unit-runtimes/*; do
  [ -f "$f" ] && sed -i "s/5e6a3f8a07c717038cb269ac05f6243a9d7021c106a9c5ef8a14bf6998533886/bdbcf3c3baffb8bb0df1c309a7ab3320822c4b7bf23eb86c218a949d9fe061f1/g" "$f"
done
cd $L/src
(umask 077; PATH=$L/tools/bin:$PATH LANE_BIN=$L/bin sh scripts/spk-platform/fixture-v4.sh $1 $P/rec1 > $L/logs/fx-$2.log 2>&1; echo FXEXIT=$? >> $L/logs/fx-$2.log) || :
