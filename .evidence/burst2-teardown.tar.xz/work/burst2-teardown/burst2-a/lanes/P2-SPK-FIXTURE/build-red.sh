set -e
export CARGO_TARGET_DIR=/srv/lanes/P2-SPK-FIXTURE/rust-target
cd /srv/lanes/P2-SPK-FIXTURE/src/native/spk-host
cargo build --features fixture-os,integration-qualification --locked --bin spk-host 2>&1 | tail -3
mkdir -p /srv/lanes/P2-SPK-FIXTURE/bin-red
cp /srv/lanes/P2-SPK-FIXTURE/rust-target/debug/spk-host /srv/lanes/P2-SPK-FIXTURE/bin-red/spk-host
