#!/bin/sh
# restart-mode.sh MODEFLAG TAG [BINDIR]: fresh copy of the pristine recording at the recorded path, run one restart mode
L=/srv/lanes/P2-SPK-FIXTURE; P=/run/user/1001/p2fx
chmod -R u+rwX $P/rec1 2>/dev/null; rm -rf $P/rec1; cp -a $P/rec1.pristine $P/rec1
cd $L/src
(umask 077; PATH=$L/tools/bin:$PATH LANE_BIN=${3:-$L/bin} SPK=$L/sntfy.spk sh scripts/spk-platform/fixture-v4.sh $1 $P/rec1 > $L/logs/fx-$2.log 2>&1; echo FXEXIT=$? >> $L/logs/fx-$2.log)
