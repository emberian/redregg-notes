set -e
export CARGO_TARGET_DIR=/srv/lanes/P2-SPK-FIXTURE/rust-target
cd /srv/lanes/P2-SPK-FIXTURE/src/native/spk-host
cargo test --features fixture-os,integration-qualification --locked --lib -- restart_finds_the_uncertain retry_v4_restart_selects retained_completion_requires 2>&1 | tee /srv/lanes/P2-SPK-FIXTURE/logs/cargo-test.log | tail -15
cargo build --features fixture-os,integration-qualification --locked --bin spk-host 2>&1 | tail -3
