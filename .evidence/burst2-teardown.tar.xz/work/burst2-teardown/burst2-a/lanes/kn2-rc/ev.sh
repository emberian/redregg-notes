#!/bin/bash
# KN2-TRIE evidence on the lane tip: exe roots, plants, art swap, journeys
L=/srv/lanes/kn2-rc; cd $L/src; . /srv/pipeline/box.env; umask 022
S=/srv/artifacts/next/bin/minidregg-link-sqlite-store
: > $L/logs/ev.status
echo "tip $(git rev-parse HEAD)" >> $L/logs/ev.status
/srv/pipeline/scripts/slot.sh swarm-build lake build $(sed -n "/^\[\[lean_exe\]\]/{n;s/^name *= *\"\(.*\)\"$/\1/p}" lakefile.toml) > $L/logs/exe-roots.log 2>&1; echo "exe-roots rc=$? $(tail -2 $L/logs/exe-roots.log | head -1)" >> $L/logs/ev.status
for p in index-tamper history-tamper; do timeout 1500 lake env lean --run scripts/kn2/$p.lean $S > $L/logs/plant-$p.log 2>&1; echo "plant $p rc=$? :: $(tail -1 $L/logs/plant-$p.log)" >> $L/logs/ev.status; done
bash scripts/kn2/check-planted-api-faults.sh > $L/logs/plant-api-faults.log 2>&1; echo "api-faults rc=$? :: $(tail -1 $L/logs/plant-api-faults.log)" >> $L/logs/ev.status
rm -rf $L/art; /srv/pipeline/scripts/fetch-artifacts next $L/art --link > $L/logs/fetch.log 2>&1; echo "fetch rc=$? $(jq -r .tip $L/art/manifest.json 2>/dev/null)" >> $L/logs/ev.status
chmod u+w $L/art/bin $L/art/manifest.json
for b in minidregg-host minidregg-client-consent; do rm -f $L/art/bin/$b; cp .lake/build/bin/$b $L/art/bin/$b; done
H=$(sha256sum $L/art/bin/minidregg-host|cut -d" " -f1); C=$(sha256sum $L/art/bin/minidregg-client-consent|cut -d" " -f1)
jq --arg h $H --arg c $C ".sha256.host=\$h | .sha256.consent=\$c | .sha256.consentHost=\$c" $L/art/manifest.json > /tmp/kn2tm.json && mv /tmp/kn2tm.json $L/art/manifest.json
echo "manifest host sha=$H consent sha=$C" >> $L/logs/ev.status
R=/run/user/$(id -u)/kn2t; rm -rf $R; mkdir -p $R
JOURNEY_STEPS="J0 J1 J2 J3 J4 J5 J6 J7 J8 JPRIV1" bash native/resource-client/journey.sh $L/art/manifest.json $R/j > $L/logs/journey.out 2> $L/logs/journey.err; echo "journey rc=$?" >> $L/logs/ev.status
echo DONE >> $L/logs/ev.status
