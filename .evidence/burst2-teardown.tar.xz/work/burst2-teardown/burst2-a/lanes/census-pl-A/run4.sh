source /srv/pipeline/box.env
cd /srv/lanes/census-pl-A/src; L=../logs
for n in audit-corrupted-leaf scripts-elab repository-trust objective-examples objective-frontend tower-controller unit-tests zkml-suite-artifact build-closure; do
 timeout 3000 scripts/check-$n.sh >$L/$n.log 2>&1; echo "$n rc=$?" >>$L/rc4.txt; done
