source /srv/pipeline/box.env
cd /srv/lanes/census-pl-A/src
timeout 6000 scripts/check-world-cohorts.sh >../logs/world-cohorts.log 2>&1; echo "world-cohorts rc=$?" >>../logs/rc5.txt
