cd /srv/lanes/census-pl-A/src; L=../logs
for n in fn-wire kernel-transport world-cohorts proof-hygiene carrier-census char2-vacuity import-boundary exports shell-paths hypothesis-ledger; do
 timeout 1500 scripts/check-$n.sh >$L/$n.log 2>&1; echo "$n rc=$?" >>$L/rc.txt; done
