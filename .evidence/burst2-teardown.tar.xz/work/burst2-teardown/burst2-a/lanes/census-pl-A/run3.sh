source /srv/pipeline/box.env
cd /srv/lanes/census-pl-A/src
timeout 2400 scripts/pipeline/lane-staleness-selftest /srv/warm-base/src /srv/lanes/census-pl-A/st1 >../logs/lane-staleness.log 2>&1; echo "lane-staleness rc=$?" >>../logs/rc3.txt
timeout 2400 scripts/pipeline/lean-ask-selftest /srv/warm-base/src /srv/lanes/census-pl-A/st2 >../logs/lean-ask.log 2>&1; echo "lean-ask rc=$?" >>../logs/rc3.txt
