source /srv/pipeline/box.env
cd /srv/lanes/census-pl-A/src; L=../logs
for g in proofs c cgen transparency; do timeout 7000 scripts/check-objective-proofs.sh $g >$L/op-$g.log 2>&1; echo "op-$g rc=$?" >>$L/rc2.txt; done
for n in audit-corrupted-leaf scripts-elab repository-trust objective-examples objective-frontend tower-controller unit-tests zkml-suite-artifact build-closure; do
 timeout 3000 scripts/check-$n.sh >$L/$n.log 2>&1; echo "$n rc=$?" >>$L/rc2.txt; done
for n in check-fixture-authority.sh lane-staleness-selftest lean-ask-selftest; do timeout 900 scripts/pipeline/$n >$L/$n.log 2>&1; echo "$n rc=$?" >>$L/rc2.txt; done
