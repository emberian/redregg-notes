#!/bin/bash
cd /srv/lanes/bench-store; ulimit -s unlimited; umask 022
for n in 3000 30000; do rm -rf data/n$n; src/.lake/build/bin/bench-store-compiled data/store-helper grow data/n$n $n > logs/grow-$n.log 2>&1; echo "EXIT $?" >> logs/grow-$n.log; done
