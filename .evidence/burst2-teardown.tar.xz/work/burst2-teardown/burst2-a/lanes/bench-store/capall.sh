#!/bin/bash
cd /srv/lanes/bench-store; ulimit -s unlimited; umask 077
export TEE_REAL_HOST=/srv/lanes/bench-store/set/bin/minidregg-host
R=src/native/resource-client
cap() { # name cmd...
  n=$1; shift
  rm -rf tee/$n run/$n; mkdir -p tee/$n
  TEE_DIR=/srv/lanes/bench-store/tee/$n TEE_WORLD=/srv/lanes/bench-store/run/$n timeout 3000 "$@" > logs/capture-$n.out 2> logs/capture-$n.err
  echo "$n EXIT $?" >> logs/capture-status.txt
}
: > logs/capture-status.txt
for d in seat:objective-seat-native-acceptance.py call:objective-call-native-journey.py send:objective-send-native-journey.py domain:objective-domain-native-journey.py upgrade:objective-upgrade-native-journey.py bounty:objective-bounty-native-acceptance.py objrec:objectrecord-native-journey.py; do
  n=${d%%:*}; f=${d#*:}
  ( cap $n python3 $R/$f --bin teebin --root run/$n ) &
done
( cap quote python3 $R/objective-activity-quote-submit-journey.py --bin teebin --root run/quote --births 12 ) &
( cap welcome bash $R/welcome-continuity-journey.sh /srv/lanes/bench-store/teebin/minidregg-host /srv/lanes/bench-store/teebin/mini /srv/lanes/bench-store/teebin/minidregg-link-sqlite-store /srv/lanes/bench-store/teebin/minidregg-credential-signature-verifier /srv/lanes/bench-store/run/welcome ) &
( cap rooms env MINI_HOST_BIN=/srv/lanes/bench-store/teebin/minidregg-host MINI_BIN=/srv/lanes/bench-store/teebin/mini MINI_STORE_BIN=/srv/lanes/bench-store/teebin/minidregg-link-sqlite-store MINI_VERIFIER_BIN=/srv/lanes/bench-store/teebin/minidregg-credential-signature-verifier bash $R/rooms-e2e.sh /srv/lanes/bench-store/run/rooms ) &
( cap journey env JOURNEY_STEPS="J0 J1 J2 J3 J4 J5 J6 J7 J8 JROT JPAY2 JRLANE" bash $R/journey.sh /srv/lanes/bench-store/teebin/manifest.json /srv/lanes/bench-store/run/journey ) &
wait
echo ALLDONE >> logs/capture-status.txt
