source ~/.profile
cd /srv/lanes/P4-PLAN-SCOPED-REPLAY/src
export PATH=$HOME/.elan/bin:$PATH
L=/srv/lanes/P4-PLAN-SCOPED-REPLAY/logs
b() {
  set -e
  cp Kernel/NativeThinConsent.lean $L/NativeThinConsent.lean.orig
  python3 - <<PY
p="Kernel/NativeThinConsent.lean"; s=open(p).read()
old="      if target.materializer.rootBytes bytes = target.expectedTargetRoot then\n        match memberPatch command target logical with"
assert s.count(old)==1
s=s.replace(old,"      if True then\n        match memberPatch command target logical with")
open(p,"w").write(s)
PY
  grep -c "if True then" Kernel/NativeThinConsent.lean > $L/mutant-applied.txt
  LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G swarm-build lake build minidregg-client-consent > $L/b5-mutant.log 2>&1 || { cp $L/NativeThinConsent.lean.orig Kernel/NativeThinConsent.lean; echo B5-MUTANT-FAIL; return; }
  cp .lake/build/bin/minidregg-client-consent $L/mutant-consent
  cp $L/NativeThinConsent.lean.orig Kernel/NativeThinConsent.lean
  LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G swarm-build lake build minidregg-host minidregg-client-consent > $L/b5-real.log 2>&1 || { echo B5-REAL-FAIL; return; }
  echo B5-OK
}
export -f b
export L
flock -n /srv/build-slot-2 bash -c b || flock -n /srv/build-slot-3 bash -c b || flock /srv/build-slot-4 bash -c b
