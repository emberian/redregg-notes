source ~/.profile
cd /srv/lanes/P4-PLAN-SCOPED-REPLAY/src
export PATH=$HOME/.elan/bin:$HOME/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/srv/lanes/P4-PLAN-SCOPED-REPLAY/target
L=/srv/lanes/P4-PLAN-SCOPED-REPLAY/logs
b() {
  LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G swarm-build lake build minidregg-host minidregg-client-consent > $L/b3-lean.log 2>&1 || { echo B3-LEAN-FAIL; return; }
  rust=$(sed -n "s/^channel *= *\"\(.*\)\"$/\1/p" rust-toolchain.toml)
  (cd native/resource-client && SWARM_MEM_MAX=24G swarm-build cargo +$rust build --release --locked -j 4) > $L/b3-cargo.log 2>&1 || { echo B3-CARGO-FAIL; return; }
  echo B3-OK
}
export -f b
export L
flock -n /srv/build-slot-2 bash -c b || flock -n /srv/build-slot-3 bash -c b || flock /srv/build-slot-4 bash -c b
