#!/usr/bin/env bash
set -uo pipefail
source ~/.profile
S=/srv/lanes/P4-PLAN-SCOPED-REPLAY/src
B=/srv/lanes/P4-PLAN-SCOPED-REPLAY/target/release
L=/srv/lanes/P4-PLAN-SCOPED-REPLAY/logs
base=${XDG_RUNTIME_DIR:-/run/user/$(id -u)}; [ -d "$base" ] && [ -w "$base" ] || base=/tmp
short=$(mktemp -d "$base/p7.XXXXXX")
jq -n --arg host "$S/.lake/build/bin/minidregg-host" --arg mini "$B/mini" --arg store "$B/minidregg-link-sqlite-store" \
  --arg verifier "$B/minidregg-credential-signature-verifier" \
  "{host:\$host, mini:\$mini, shell:\$mini, store:\$store, verifier:\$verifier}" > $L/p7-manifest.json
echo "run root $short/r"
JOURNEY_STEPS="J0 J1 J2 J3 J4 P7KR" bash $S/native/resource-client/journey.sh $L/p7-manifest.json $short/r
echo "JOURNEY-EXIT $?"
rm -rf $L/p7-run-copy2; cp -a $short/r $L/p7-run-copy2 2>/dev/null
echo COPIED
