/srv/lanes/P4-PLAN-SCOPED-REPLAY/target/release/mini workspace --action read --dir /run/user/1001/p7.mHM99f/r/world/newcomer-workspace --name shared 
