/srv/lanes/P4-PLAN-SCOPED-REPLAY/target/release/mini workspace --action read --dir /run/user/1001/p7.Ktv9IO/r/world/newcomer-workspace --name shared 
