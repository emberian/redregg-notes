source ~/.profile
cd /srv/lanes/P4-PLAN-SCOPED-REPLAY/src
export PATH=$HOME/.elan/bin:$PATH
b() { LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G swarm-build lake build minidregg-client-consent minidregg-client-consent-specialized > /srv/lanes/P4-PLAN-SCOPED-REPLAY/logs/p7-consent.log 2>&1 && echo BUILD2-OK || echo BUILD2-FAIL; }
export -f b
flock -n /srv/build-slot-2 bash -c b || flock -n /srv/build-slot-3 bash -c b || flock /srv/build-slot-4 bash -c b
