/srv/lanes/P4-PLAN-SCOPED-REPLAY/target/release/mini enroll --action lookup --dir /run/user/1001/p7.mHM99f/r/world/attempts/newcomer 
