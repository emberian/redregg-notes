/srv/lanes/P4-PLAN-SCOPED-REPLAY/target/release/mini enroll --action submit --dir /run/user/1001/p7.Ktv9IO/r/world/attempts/newcomer 
