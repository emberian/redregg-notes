#!/usr/bin/env bash
set -uo pipefail
source ~/.profile
cd /srv/lanes/P4-PLAN-SCOPED-REPLAY/src
L=/srv/lanes/P4-PLAN-SCOPED-REPLAY/logs
export PATH=$HOME/.elan/bin:$HOME/.cargo/bin:$PATH
export CARGO_TARGET_DIR=/srv/lanes/P4-PLAN-SCOPED-REPLAY/target
rust=$(sed -n "s/^channel *= *\"\(.*\)\"$/\1/p" rust-toolchain.toml)
build() {
  LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G swarm-build lake build minidregg-host >$L/p7-host.log 2>&1 || { echo HOST-FAIL; return 1; }
  for c in resource-client hyperdocument-link-sqlite-store credential-signature-verifier; do
    (cd native/$c && SWARM_MEM_MAX=24G swarm-build cargo +$rust build --release --locked -j 4) >$L/p7-cargo-$c.log 2>&1 || { echo CARGO-FAIL $c; return 1; }
  done
  echo BUILD-OK
}
export -f build
flock -n /srv/build-slot-2 bash -c "L=$L rust=$rust build" || flock -n /srv/build-slot-3 bash -c "L=$L rust=$rust build" || flock /srv/build-slot-4 bash -c "L=$L rust=$rust build"
