#!/bin/bash -l
L=/srv/lanes/plat-p7-opids
export CARGO_TARGET_DIR=$L/rust-target
{ (cd $L/src/native/resource-client && nice -n 15 cargo build -j 8 --bin mini) && cp -f $CARGO_TARGET_DIR/debug/mini $L/jbin/mini && echo CARGO-OK || echo CARGO-FAIL; } > $L/logs/cargo-opids.log 2>&1
