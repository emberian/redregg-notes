#!/bin/bash
# usage: build.sh TAG  -- full closure; on success copies host+consent into jbin
. /srv/pipeline/box.env
cd /srv/lanes/plat-p7-opids/src
LOG=/srv/lanes/plat-p7-opids/logs/full-$1.log
/srv/pipeline/scripts/slot.sh swarm-build lake build Kernel Host ObjectiveProofs minidregg-host minidregg-client-consent > $LOG 2>&1
rc=$?; echo "EXIT $rc" >> $LOG; [ $rc = 0 ] && cp -f .lake/build/bin/minidregg-host .lake/build/bin/minidregg-client-consent /srv/lanes/plat-p7-opids/jbin/
