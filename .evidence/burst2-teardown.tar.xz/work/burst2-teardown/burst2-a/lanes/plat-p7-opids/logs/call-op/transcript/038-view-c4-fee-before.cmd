/srv/lanes/plat-p7-opids/jbin-op/mini activity --action view --workspace /run/user/1001/pcop/c/w/sponsor --request {"accounts": ["7", "40", "99"]}
