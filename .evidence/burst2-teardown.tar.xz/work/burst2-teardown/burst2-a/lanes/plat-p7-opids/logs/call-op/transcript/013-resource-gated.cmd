/srv/lanes/plat-p7-opids/jbin-op/mini workspace --action create --dir /run/user/1001/pcop/c/w/sponsor --name gated --storage content --predicate /run/user/1001/pcop/c/permit-all.json
