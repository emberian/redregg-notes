/srv/lanes/plat-p7-opids/jbin-op/mini keygen --secret /run/user/1001/pcop/c/second.key --public /run/user/1001/pcop/c/second.pub
