/srv/lanes/plat-p7-opids/jbin-op/minidregg-host /dev/null objective-constants
