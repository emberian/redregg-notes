/srv/lanes/plat-p7-opids/jbin-op/minidregg-host /dev/null author objective-policy /run/user/1001/pcop/c/policy.json /run/user/1001/pcop/c/policy.hex
