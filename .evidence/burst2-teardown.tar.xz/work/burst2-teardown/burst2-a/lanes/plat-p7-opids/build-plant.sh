#!/bin/bash
# usage: build-plant.sh PLANT  -- plant, build the Host, copy into jbin-PLANT, restore the file. Never commits.
. /srv/pipeline/box.env
L=/srv/lanes/plat-p7-opids; P=$1; LOG=$L/logs/plant-$P-build.log
cd $L/src && python3 $L/plant.py $P > $LOG 2>&1 && git diff --stat >> $LOG && /srv/pipeline/scripts/slot.sh swarm-build lake build minidregg-host minidregg-client-consent >> $LOG 2>&1
rc=$?; echo "EXIT $rc" >> $LOG
if [ $rc = 0 ]; then rm -rf $L/jbin-$P; cp -a $L/jbin $L/jbin-$P; rm -f $L/jbin-$P/minidregg-host $L/jbin-$P/minidregg-client-consent; cp .lake/build/bin/minidregg-host .lake/build/bin/minidregg-client-consent $L/jbin-$P/; fi
git checkout -- Kernel/ObjectiveActivityReceiver.lean; git status --short | grep -v "^??" >> $LOG; echo RESTORED >> $LOG
