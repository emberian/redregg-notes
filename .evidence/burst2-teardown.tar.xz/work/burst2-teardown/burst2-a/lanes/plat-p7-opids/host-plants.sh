#!/bin/bash
L=/srv/lanes/plat-p7-opids
for p in replay-exact no-claim retry-unverified; do
  $L/build-plant.sh $p
  if grep -q "^EXIT 0" $L/logs/plant-$p-build.log; then BIN=$L/jbin-$p $L/run-send.sh hp-$p; else echo "BUILD FAILED $p" >> $L/logs/host-plants.log; fi
done
echo DONE >> $L/logs/host-plants.log
