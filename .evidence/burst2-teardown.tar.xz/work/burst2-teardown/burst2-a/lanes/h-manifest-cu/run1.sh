#!/usr/bin/env bash
cd /srv/lanes/h-manifest-cu/src && source ~/.profile
L=../logs
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs > $L/cu-gate-check.log 2>&1; echo "EXIT $?" >> $L/cu-gate-check.log
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh bash scripts/check-objective-proofs.sh proofs --draft > $L/cu-draft.log 2>&1; echo "EXIT $?" >> $L/cu-draft.log
echo ALLDONE >> $L/cu-draft.log
