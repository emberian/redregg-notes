#!/usr/bin/env bash
cd /srv/lanes/h-manifest-cu/src && source ~/.profile
L=../logs
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs --pin > $L/cu-pin.log 2>&1; echo "EXIT $?" >> $L/cu-pin.log
LEAN_NUM_THREADS=5 /srv/pipeline/scripts/slot.sh /usr/bin/time -f "WALL %e s MAXRSS %M KB" bash scripts/check-objective-proofs.sh proofs > $L/cu-after-pin.log 2>&1; echo "EXIT $?" >> $L/cu-after-pin.log
echo ALLDONE >> $L/cu-after-pin.log
