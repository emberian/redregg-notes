L=/srv/lanes/kn2-row-e-a; B=$L/artifacts; S=$L/src/native/resource-client
run() { n=$1; shift; rm -rf $L/j/$n; python3 "$@" --bin $B --root $L/j/$n > $L/j/$n.log 2>&1; echo "$n EXIT $?" >> $L/j/summary.txt; }
rm -rf $L/j/native-disabled; : > $L/j/summary.txt
run charged $S/objective-charged-failure-journey.py &
run work $S/objective-work-account-journey.py &
run activity $S/objective-activity-native-acceptance.py &
run quote $S/objective-activity-quote-submit-journey.py --births 10 &
run send $S/objective-send-native-journey.py &
run call $S/objective-call-native-journey.py &
run domain $S/objective-domain-native-journey.py &
run seat $S/objective-seat-native-acceptance.py &
run bounty $S/objective-bounty-native-acceptance.py &
run native $S/objective-native-acceptance.py all &
run upgrade $S/objective-upgrade-native-journey.py &
run objectrecord $S/objectrecord-native-journey.py &
wait
echo ALLDONE >> $L/j/summary.txt
