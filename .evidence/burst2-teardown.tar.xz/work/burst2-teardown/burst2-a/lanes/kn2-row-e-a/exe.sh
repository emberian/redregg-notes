cd /srv/lanes/kn2-row-e-a/src
/srv/pipeline/scripts/lake-slot $(sed -n "/^\[\[lean_exe\]\]/{n;s/^name *= *\"\(.*\)\"$/\1/p}" lakefile.toml) Host.Main ObjectiveProofs Kernel Kernel.ObjectiveActivityGateRoute > /srv/lanes/kn2-row-e-a/logs/exe-roots.log 2>&1
echo EXIT $? >> /srv/lanes/kn2-row-e-a/logs/exe-roots.log
