L=/srv/lanes/kn2-row-e-a; B=$L/artifacts; S=$L/src/native/resource-client
run() { n=$1; shift; rm -rf $L/j/$n; python3 "$@" --bin $B --root $L/j/$n > $L/j/$n.log 2>&1; echo "$n EXIT $?" >> $L/j/summary2.txt; }
: > $L/j/summary2.txt
for x in "$@"; do case $x in
 call) run call $S/objective-call-native-journey.py & ;;
 send) run send $S/objective-send-native-journey.py & ;;
 activity) run activity $S/objective-activity-native-acceptance.py & ;;
 objectrecord) run objectrecord $S/objectrecord-native-journey.py & ;;
 upgrade) run upgrade $S/objective-upgrade-native-journey.py & ;;
esac; done
wait; echo ALLDONE >> $L/j/summary2.txt
