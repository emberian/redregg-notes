# Range (a) plant: loadMethod skips its draws (returns the meter it was given). Host AND consent planted
# (the client's plan runs the same kernel). Expected red: call C11 (c11-three-frames-draw-more,
# c11-one-byte-short) and send S1 (s1-postage-short).
L=/srv/lanes/kn2-row-e-a; export LANE_DIR=$L; cd $L/src || exit 2
while ! grep -q PIPELINEDONE $L/logs/exe-roots.log; do sleep 30; done
git checkout -q -B plant-a e3a
python3 - <<'PY'
p='Kernel/ObjectiveCall.lean'
s=open(p).read()
a='''  | .error reason => .error (reason, quoted)
  | .ok drawn => .ok (m, drawn)'''
assert s.count(a)==1
s=s.replace(a,'''  | .error reason => .error (reason, quoted)
  | .ok _ => .ok (m, meter)''')
open(p,'w').write(s)
PY
git diff > $L/logs/plant-a.diff
git -c commit.gpgsign=false -c user.name=plant -c user.email=plant@x commit -qam "PLANT: loadMethod skips its draws"
mkdir -p $L/tip; for d in artifacts native-out consent-out cycle; do [ -e $L/$d ] && mv $L/$d $L/tip/; done
for step in host consent; do
  for i in $(seq 1 60); do
    if [ $step = host ]; then args="host --umbrella --umbrella-target Host.Main"; out=native-out; else args=consent; out=consent-out; fi
    /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh $args > $L/logs/plant-$step.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/plant-$step.log
    [ $rc -eq 75 ] || break
    mv $L/$out $L/$out-pr$i-$$; sleep 60
  done
  grep -q "^EXIT 0" $L/logs/plant-$step.log || { echo PLANT BUILD RED $step >> $L/logs/plant-a.out; exit 1; }
done
rm -rf $L/binplant; mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip/artifacts/*; do ln -sf $f .; done
rm -f minidregg-host minidregg-client-consent; cp $L/artifacts/minidregg-host .; cp $L/artifacts/minidregg-client-consent .
sha256sum minidregg-host minidregg-client-consent $L/tip/artifacts/minidregg-host $L/tip/artifacts/minidregg-client-consent >> $L/logs/plant-a.out
S=$L/src/native/resource-client
rm -rf $L/j/plant-call $L/j/plant-send
python3 $S/objective-call-native-journey.py --bin $L/binplant --root $L/j/plant-call > $L/j/plant-call.log 2>&1; echo "plant-call EXIT $?" >> $L/logs/plant-a.out &
python3 $S/objective-send-native-journey.py --bin $L/binplant --root $L/j/plant-send > $L/j/plant-send.log 2>&1; echo "plant-send EXIT $?" >> $L/logs/plant-a.out &
wait
cd $L/src && git checkout -q e3a
echo PLANTDONE >> $L/logs/plant-a.out
