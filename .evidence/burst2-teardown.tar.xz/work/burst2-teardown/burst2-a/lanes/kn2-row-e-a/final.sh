L=/srv/lanes/kn2-row-e-a; cd $L/src; export LANE_DIR=$L
bash -l $L/exe.sh
for c in "full-loaded-ratchet bash scripts/ports/check-full-loaded-callers.sh" "scripts-elab bash scripts/check-scripts-elab.sh" "proof-hygiene bash scripts/check-proof-hygiene.sh" "import-boundary bash scripts/check-import-boundary.sh" "exports bash scripts/check-exports.sh" "build-surfaces python3 scripts/lean-build-surfaces.py check"; do
  n=${c%% *}; cmd=${c#* }; bash -lc "cd $L/src && $cmd" > $L/logs/check-$n.log 2>&1; echo "$n rc=$?" >> $L/logs/checks.summary
done
bash $L/pipeline.sh > $L/logs/pipeline.out 2>&1
bash $L/plant-a.sh > $L/logs/plant-a.sh.out 2>&1
