# Behavioural plant (a), v2: loadMethod returns the meter it was given (skips both draws). The proofs that this
# falsifies (loadMethod_reaches, loadMethod_draws: the Lean plant already showed them red) are replaced by sorry and
# ObjectiveCall's #assert_axioms lines dropped ON THE PLANT BRANCH ONLY, so the Host compiles and the journeys can judge it.
L=/srv/lanes/kn2-row-e-a; export LANE_DIR=$L; cd $L/src || exit 2
git checkout -q -f -B plant-a e3a
python3 - <<'PY'
import re, glob
p='Kernel/ObjectiveCall.lean'
s=open(p).read()
a='''  | .error reason => .error (reason, quoted)
  | .ok drawn => .ok (m, drawn)'''
assert s.count(a)==1
s=s.replace(a,'''  | .error reason => .error (reason, quoted)
  | .ok _ => .ok (m, meter)''')
for name in ('theorem loadMethod_reaches', 'theorem loadMethod_draws'):
    i=s.index(name); j=s.index(':= by\n', i)+len(':= by\n'); k=s.index('\n\n', j)
    s=s[:j]+'  sorry'+s[k:]
open(p,'w').write(s)
s=open(p).read()
s=re.sub(r'^#assert_axioms .*\n', '', s, flags=re.M)
open(p,'w').write(s)
PY
git diff --stat > $L/logs/plant-a.diffstat; git diff Kernel/ObjectiveCall.lean | head -80 > $L/logs/plant-a.diff
git -c commit.gpgsign=false -c user.name=plant -c user.email=plant@x commit -qam "PLANT: loadMethod skips its draws (proofs it falsifies sorried, asserts dropped)"
mkdir -p $L/tip; for d in artifacts native-out consent-out cycle; do [ -e $L/$d ] && { rm -rf $L/tip/$d-plantfail; [ -e $L/tip/$d ] && mv $L/$d $L/tip/$d-plantfail || mv $L/$d $L/tip/; }; done
: > $L/logs/plant-a.out
for step in host consent; do
  for i in $(seq 1 60); do
    if [ $step = host ]; then args="host --umbrella --umbrella-target Host.Main"; out=native-out; else args=consent; out=consent-out; fi
    /srv/pipeline/scripts/slot.sh swarm-build deploy/candidate/lane-build.sh $args > $L/logs/plant-$step.log 2>&1; rc=$?; echo EXIT $rc >> $L/logs/plant-$step.log
    [ $rc -eq 75 ] || break
    mv $L/$out $L/$out-pr$i-$$; sleep 60
  done
  grep -q "^EXIT 0" $L/logs/plant-$step.log || { echo PLANT BUILD RED $step >> $L/logs/plant-a.out; cd $L/src; git checkout -q -f e3a; exit 1; }
done
rm -rf $L/binplant; mkdir -p $L/binplant; cd $L/binplant; for f in $L/tip/artifacts/*; do ln -sf $f .; done
rm -f minidregg-host minidregg-client-consent; cp $L/artifacts/minidregg-host .; cp $L/artifacts/minidregg-client-consent .
sha256sum minidregg-host minidregg-client-consent $L/tip/artifacts/minidregg-host $L/tip/artifacts/minidregg-client-consent >> $L/logs/plant-a.out
S=$L/src/native/resource-client
rm -rf $L/j/plant-call $L/j/plant-send
python3 $S/objective-call-native-journey.py --bin $L/binplant --root $L/j/plant-call > $L/j/plant-call.log 2>&1; echo "plant-call EXIT $?" >> $L/logs/plant-a.out &
python3 $S/objective-send-native-journey.py --bin $L/binplant --root $L/j/plant-send > $L/j/plant-send.log 2>&1; echo "plant-send EXIT $?" >> $L/logs/plant-a.out &
wait
cd $L/src && git checkout -q -f e3a
echo PLANTDONE >> $L/logs/plant-a.out
