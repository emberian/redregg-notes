#!/bin/bash
cd /srv/lanes/kn2-store-open/src/native/hyperdocument-link-sqlite-store
export CARGO_TARGET_DIR=/srv/lanes/kn2-store-open/rust-target
run() { swarm-build cargo test --release --offline --locked 2>&1; }
export -f run
( flock -n /srv/build-slot-2 bash -c run || flock -n /srv/build-slot-3 bash -c run || flock /srv/build-slot-4 bash -c run ) > /srv/lanes/kn2-store-open/logs/rust-test-3.log 2>&1
echo "EXIT $?" >> /srv/lanes/kn2-store-open/logs/rust-test-3.log
