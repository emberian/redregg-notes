#!/bin/bash -l
cd /srv/lanes/kn2-forcing/src
export LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G
L=/srv/lanes/kn2-forcing/logs
run() { flock -n /srv/build-slot-2 "$@" || flock -n /srv/build-slot-3 "$@" || flock /srv/build-slot-4 "$@"; }
run swarm-build bash scripts/check-objective-proofs.sh proofs --update > $L/proofs-update.log 2>&1; echo "PROOFS_RC=$?" >> $L/p1.status
run swarm-build bash scripts/check-objective-proofs.sh transparency > $L/transparency-01.log 2>&1; echo "TRANSP_RC=$?" >> $L/p1.status
