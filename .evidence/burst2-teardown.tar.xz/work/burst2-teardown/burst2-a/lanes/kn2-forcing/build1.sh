#!/bin/bash -l
cd /srv/lanes/kn2-forcing/src
export LEAN_NUM_THREADS=4 SWARM_MEM_MAX=24G
CMD="swarm-build lake build ObjectiveProofs Kernel.ObjectiveResumeContract Kernel.ObjectiveCheckpointInvariant Theory.ObjectiveBendLedgerPoles"
flock -n /srv/build-slot-2 $CMD || flock -n /srv/build-slot-3 $CMD || flock /srv/build-slot-4 $CMD
echo "RC=$?"
