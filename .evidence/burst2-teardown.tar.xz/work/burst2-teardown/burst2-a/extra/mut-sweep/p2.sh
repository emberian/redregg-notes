# p2.sh: build per-lane survivor lists from local out/ and start mut-journey workers on given lanes
cd /srv/lanes/mut-sweep; mkdir -p jout
python3 - "$@" <<'P'
import json,glob,sys
lanes=sys.argv[1:]
S=[]
A={json.loads(l)['id']:l for l in open('all.jsonl')}
for f in sorted(glob.glob('out/*.json')):
    j=json.load(open(f))
    if j['verdict']=='BUILD-GREEN': S.append(j)
import os
S=[j for j in S if not os.path.exists(f"jout/{j['id']}.json")]
for i,l in enumerate(lanes):
    with open(f'jsurv_{l}.jsonl','w') as o:
        for j in S: o.write(A[j['id']].rstrip('\n')+'\n')
print(len(S),'survivors over',len(lanes),'lanes')
P
for l in "$@"; do (cd /srv/lanes/$l/src && git checkout -q -- Kernel); setsid nohup bash ./mut-journey.sh $l /srv/lanes/mut-sweep/jsurv_$l.jsonl /srv/lanes/mut-sweep/jout > jw_$l.log 2>&1 < /dev/null & done
