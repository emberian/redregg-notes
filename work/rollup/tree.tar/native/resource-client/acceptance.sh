#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
  echo "usage: $0 MINIDREGG_HOST NEW_EVIDENCE_DIRECTORY" >&2
  exit 2
fi

HOST=$1
EVIDENCE=$2
HERE=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
REPO=$(CDPATH='' cd -- "$HERE/../.." && pwd)
MINI=${MINI:-"$HERE/target/debug/mini"}
STORE_BINARY=${STORE_BINARY:-"$REPO/native/hyperdocument-link-sqlite-store/target/debug/minidregg-link-sqlite-store"}
SIGNATURE_BINARY=${SIGNATURE_BINARY:-"$REPO/native/credential-signature-verifier/target/debug/minidregg-credential-signature-verifier"}

for executable in "$HOST" "$MINI" "$STORE_BINARY" "$SIGNATURE_BINARY"; do
  if [ ! -x "$executable" ]; then
    echo "not executable: $executable" >&2
    exit 2
  fi
done
if ! command -v jq >/dev/null 2>&1; then
  echo "jq is required for acceptance assertions" >&2
  exit 2
fi
if [ -e "$EVIDENCE" ]; then
  echo "refusing to replace evidence directory: $EVIDENCE" >&2
  exit 2
fi
mkdir "$EVIDENCE"
EVIDENCE=$(CDPATH='' cd -- "$EVIDENCE" && pwd)

receipt_field() {
  jq -er --arg field "$2" \
    '.[$field] | select(type == "string" and test("^(0|[1-9][0-9]*)$"))' "$1"
}

page_root() {
  jq -er '.cell.root | select(type == "string" and test("^(0|[1-9][0-9]*)$"))' "$1"
}

challenge_field() {
  jq -er --arg field "$2" \
    '.[$field] | select(type == "string" and test("^(0|[1-9][0-9]*)$"))' "$1"
}

"$MINI" keygen --secret "$EVIDENCE/alice.key" --public "$EVIDENCE/alice.pub" \
  >"$EVIDENCE/public-key.txt"
PUBLIC_KEY=$(od -An -tx1 -v "$EVIDENCE/alice.pub" | tr -d ' \n')

cat >"$EVIDENCE/operator.json" <<EOF
{
  "domain": 8501,
  "federation": 9,
  "factoryId": 10,
  "resourceBookId": 11,
  "authorityCellId": 12,
  "issuer": 5,
  "ownerBudget": 100000,
  "lifetime": 10000,
  "tariffBase": 3,
  "tariffPerBirth": 2,
  "tariffPerGrant": 1,
  "tariffPerInitialPayloadByte": 0,
  "collector": 99,
  "asset": 0,
  "genesisHeight": 10,
  "expectedSeed": 0,
  "storageBinary": "$STORE_BINARY",
  "storageRoot": "$EVIDENCE/store",
  "signatureBinary": "$SIGNATURE_BINARY"
}
EOF

"$HOST" "$EVIDENCE/operator.json" profile >"$EVIDENCE/operator-profile.json"
SEMANTICS=$(jq -er '.semantics' "$EVIDENCE/operator-profile.json")

cat >"$EVIDENCE/genesis.json" <<EOF
{
  "domain": "8501",
  "factoryId": "10",
  "resourceBookId": "11",
  "authorityCellId": "12",
  "federation": "9",
  "tariffBase": "3",
  "tariffPerBirth": "2",
  "tariffPerGrant": "1",
  "tariffPerInitialPayloadByte": "0",
  "collector": "99",
  "asset": "0",
  "expectedSemantics": "$SEMANTICS",
  "issuerEpoch": "2",
  "genesisHeight": "10",
  "factoryPredicate": {"type": "all", "predicates": []},
  "enrollments": [{
    "key": {
      "keyId": "7007",
      "keyEpoch": "2",
      "algorithm": "1",
      "subject": "7",
      "publicKey": "$PUBLIC_KEY",
      "activeFrom": "0",
      "activeUntil": "1000000",
      "nextKeyDigest": null
    },
    "accountId": "7",
    "spendCapabilityId": "41",
    "controlCapabilityId": "51",
    "factoryObserveCapabilityId": "54",
    "initialBalance": "100",
    "accountPredicate": {"type": "all", "predicates": []}
  }],
  "factoryControllerSubject": "7",
  "factoryControllerCapability": "53",
  "clockTickers": [],
  "tailBound":"256",
  "meterAllowance": {
    "incidences": "10000000",
    "turnBytes": "10000000",
    "memoryTouches": "10000000",
    "witnessBytes": "10000000",
    "proofWork": "10000000",
    "storageBytes": "10000000",
    "networkBytes": "10000000",
    "sideEffectCount": "10000000",
    "feeDebit": "10000000",
    "leaseByteBlocks": "10000000"
  }
}
EOF

"$MINI" bootstrap --host "$HOST" --config "$EVIDENCE/operator.json" \
  --source "$EVIDENCE/genesis.json" --dir "$EVIDENCE/deployment" \
  >"$EVIDENCE/bootstrap.stdout"
CONFIG="$EVIDENCE/deployment/pinned-config.json"

cat >"$EVIDENCE/birth-intent.json" <<EOF
{
  "subject": "7",
  "nonce": "22000",
  "birth": {
    "genesis": $(cat "$EVIDENCE/genesis.json"),
    "template": {"issuer": "5", "ownerBudget": "100000", "lifetime": "10000"},
    "creator": "7",
    "nonce": "22000",
    "resources": [
      {
        "kind": "object",
        "storage": "content",
        "target": "600",
        "owner": "7",
        "ownerCapability": "61",
        "controlCapability": "62",
        "predicate": {"type": "all", "predicates": []}
      },
      {
        "kind": "object",
        "storage": "declared",
        "target": "601",
        "owner": "7",
        "ownerCapability": "63",
        "controlCapability": "64",
        "predicate": {"type": "all", "predicates": []},
        "fields": ["0"]
      }
    ],
    "sourceCapabilities": ["41"],
    "funding": [],
    "feePayer": "7"
  },
  "grants": [
    {"kind": "object", "target": "10", "capability": "54"},
    {"kind": "account", "target": "7", "capability": "41"}
  ]
}
EOF

"$MINI" submit --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/birth-intent.json" --intent-kind birth-intent \
  --key "$EVIDENCE/alice.key" --dir "$EVIDENCE/birth-attempt" \
  >"$EVIDENCE/birth.stdout"
jq -e '.type == "confirmed" and .confirmation == "installed"' \
  "$EVIDENCE/birth-attempt/outcome.json" >/dev/null

cat >"$EVIDENCE/query-before.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30001",
  "purpose": {"type": "query", "kind": "object", "target": "600", "view": "resource"},
  "grants": [{"kind": "object", "target": "600", "capability": "61"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-before.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-before" >"$EVIDENCE/query-before.stdout"
TARGET_ROOT=$(page_root "$EVIDENCE/query-before/view.json")
AUTHORITY_ROOT=$(jq -er '.authorityRoot |
  select(type == "string" and test("^(0|[1-9][0-9]*)$"))' \
  "$EVIDENCE/query-before/challenge.json")
jq -e '.cell.entries == []' "$EVIDENCE/query-before/view.json" >/dev/null

cat >"$EVIDENCE/content-intent.json" <<EOF
{
  "subject": "7",
  "nonce": "30002",
  "purpose": {
    "type": "prepare",
    "draft": {
      "type": "invoke",
      "command": {
        "subject": "7",
        "nonce": "30003",
        "targets": [{
          "kind": "object",
          "target": "600",
          "capability": "61",
          "observeCapability": null,
          "schemaVersion": "1",
          "expectedTargetRoot": "$TARGET_ROOT",
          "payload": {
            "type": "content",
            "actions": [{
              "type": "createDocument",
              "rootElement": "1001",
              "schema": "1"
            }]
          }
        }]
      }
    }
  },
  "grants": [{"kind": "object", "target": "600", "capability": "61"}]
}
EOF

printf '%s\n' "$HOST" >"$EVIDENCE/real-host-path"
cat >"$EVIDENCE/drop-first-submit.sh" <<'EOF'
#!/bin/sh
set -eu
SELF=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
REAL_HOST=$(cat "$SELF/real-host-path")
if [ "$2" = submit ] && mkdir "$SELF/submit-output-dropped.once" 2>/dev/null; then
  exec "$REAL_HOST" "$1" "$2" "$3" "$SELF/nonexistent-output-parent/outcome.bin"
fi
exec "$REAL_HOST" "$@"
EOF
chmod 755 "$EVIDENCE/drop-first-submit.sh"

if "$MINI" submit --host "$EVIDENCE/drop-first-submit.sh" --config "$CONFIG" \
  --intent "$EVIDENCE/content-intent.json" --key "$EVIDENCE/alice.key" \
  --dir "$EVIDENCE/content-attempt" >"$EVIDENCE/content-lost.stdout" \
  2>"$EVIDENCE/content-lost.stderr"; then
  echo "expected first content submission to lose its outcome" >&2
  exit 1
fi
test -f "$EVIDENCE/content-attempt/call.bin"
test ! -e "$EVIDENCE/content-attempt/outcome.bin"
test ! -e "$EVIDENCE/content-attempt/outcome.json"

CALL_HASH_BEFORE=$(shasum -a 256 "$EVIDENCE/content-attempt/call.bin" | awk '{print $1}')
"$MINI" retry --attempt "$EVIDENCE/content-attempt" --mode submit \
  >"$EVIDENCE/retry-submit.stdout"
"$MINI" retry --attempt "$EVIDENCE/content-attempt" --mode lookup \
  >"$EVIDENCE/retry-lookup.stdout"
CALL_HASH_AFTER=$(shasum -a 256 "$EVIDENCE/content-attempt/call.bin" | awk '{print $1}')
test "$CALL_HASH_BEFORE" = "$CALL_HASH_AFTER"
jq -e '.type == "confirmed" and .confirmation == "replayed"' \
  "$EVIDENCE/content-attempt/retry-0001.json" >/dev/null
jq -e '.type == "confirmed" and .confirmation == "replayed"' \
  "$EVIDENCE/content-attempt/retry-0002.json" >/dev/null
for field in transactionId eventId acceptedCount worldRoot; do
  first_value=$(receipt_field "$EVIDENCE/content-attempt/retry-0001.json" "$field")
  second_value=$(receipt_field "$EVIDENCE/content-attempt/retry-0002.json" "$field")
  test "$first_value" = "$second_value"
done

cat >"$EVIDENCE/query-after.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30004",
  "purpose": {"type": "query", "kind": "object", "target": "600", "view": "resource"},
  "grants": [{"kind": "object", "target": "600", "capability": "61"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-after.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-after" >"$EVIDENCE/query-after.stdout"
jq -e '[.cell.entries[].type] | sort == ["document", "element"]' \
  "$EVIDENCE/query-after/view.json" >/dev/null
CONTENT_ROOT=$(page_root "$EVIDENCE/query-after/view.json")
test "$TARGET_ROOT" != "$CONTENT_ROOT"
CONTENT_HEIGHT=$(challenge_field "$EVIDENCE/query-after/challenge.json" height)
CONTENT_BOUNDARY=$(challenge_field "$EVIDENCE/query-after/challenge.json" worldRoot)
CONTENT_RECEIPT_BOUNDARY=$(receipt_field "$EVIDENCE/content-attempt/retry-0001.json" worldRoot)
test "$CONTENT_HEIGHT" = "12"
test "$CONTENT_BOUNDARY" = "$CONTENT_RECEIPT_BOUNDARY"

cat >"$EVIDENCE/query-scalar-before.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30005",
  "purpose": {"type": "query", "kind": "object", "target": "601", "view": "resource"},
  "grants": [{"kind": "object", "target": "601", "capability": "63"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-scalar-before.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-scalar-before" >"$EVIDENCE/query-scalar-before.stdout"
SCALAR_ROOT=$(page_root "$EVIDENCE/query-scalar-before/view.json")
JOINT_AUTHORITY_ROOT=$(jq -er '.authorityRoot |
  select(type == "string" and test("^(0|[1-9][0-9]*)$"))' \
  "$EVIDENCE/query-scalar-before/challenge.json")
jq -e '(.cell.entries | length) == 0 and .cell.declaration == ["0"]' \
  "$EVIDENCE/query-scalar-before/view.json" >/dev/null

cat >"$EVIDENCE/joint-intent.json" <<EOF
{
  "subject": "7",
  "nonce": "30006",
  "purpose": {
    "type": "prepare",
    "draft": {
      "type": "invoke",
      "command": {
        "subject": "7",
        "nonce": "30007",
        "targets": [
          {
            "kind": "object",
            "target": "600",
            "capability": "61",
            "observeCapability": "61",
            "schemaVersion": "1",
            "expectedTargetRoot": "$CONTENT_ROOT",
            "payload": {
              "type": "content",
              "actions": [{
                "type": "createAtom",
                "atom": "7001",
                "kind": {"type": "text"},
                "payload": "68656c6c6f"
              }]
            }
          },
          {
            "kind": "object",
            "target": "601",
            "capability": "63",
            "observeCapability": "63",
            "schemaVersion": "1",
            "expectedTargetRoot": "$SCALAR_ROOT",
            "payload": {
              "type": "scalar",
              "actions": [{
                "type": "create",
                "key": {"type": "object", "resource": "601", "field": "0"},
                "value": "1"
              }]
            }
          }
        ]
      }
    }
  },
  "grants": [
    {"kind": "object", "target": "600", "capability": "61"},
    {"kind": "object", "target": "601", "capability": "63"}
  ]
}
EOF

"$MINI" submit --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/joint-intent.json" --key "$EVIDENCE/alice.key" \
  --dir "$EVIDENCE/joint-attempt" >"$EVIDENCE/joint.stdout"
jq -e '.type == "confirmed" and .confirmation == "installed" and .acceptedCount == "3"' \
  "$EVIDENCE/joint-attempt/outcome.json" >/dev/null
jq -e '[.slots[].role] | index("8") != null' "$EVIDENCE/joint-attempt/plan.json" >/dev/null

cat >"$EVIDENCE/query-joint-before-retry.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30010",
  "purpose": {"type": "query", "kind": "object", "target": "600", "view": "resource"},
  "grants": [{"kind": "object", "target": "600", "capability": "61"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-joint-before-retry.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-joint-before-retry" >"$EVIDENCE/query-joint-before-retry.stdout"
JOINT_BEFORE_RETRY_BOUNDARY=$(challenge_field \
  "$EVIDENCE/query-joint-before-retry/challenge.json" worldRoot)
JOINT_BEFORE_RETRY_HEIGHT=$(challenge_field \
  "$EVIDENCE/query-joint-before-retry/challenge.json" height)
JOINT_RECEIPT_BOUNDARY=$(receipt_field "$EVIDENCE/joint-attempt/outcome.json" worldRoot)
test "$JOINT_BEFORE_RETRY_HEIGHT" = "13"
test "$JOINT_BEFORE_RETRY_BOUNDARY" = "$JOINT_RECEIPT_BOUNDARY"

JOINT_CALL_HASH_BEFORE=$(shasum -a 256 "$EVIDENCE/joint-attempt/call.bin" | awk '{print $1}')
"$MINI" retry --attempt "$EVIDENCE/joint-attempt" --mode submit \
  >"$EVIDENCE/joint-retry-submit.stdout"
JOINT_CALL_HASH_AFTER=$(shasum -a 256 "$EVIDENCE/joint-attempt/call.bin" | awk '{print $1}')
test "$JOINT_CALL_HASH_BEFORE" = "$JOINT_CALL_HASH_AFTER"
jq -e '.type == "confirmed" and .confirmation == "replayed" and .acceptedCount == "3"' \
  "$EVIDENCE/joint-attempt/retry-0001.json" >/dev/null
for field in transactionId eventId acceptedCount worldRoot; do
  first_value=$(receipt_field "$EVIDENCE/joint-attempt/outcome.json" "$field")
  second_value=$(receipt_field "$EVIDENCE/joint-attempt/retry-0001.json" "$field")
  test "$first_value" = "$second_value"
done

cat >"$EVIDENCE/query-content-final.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30008",
  "purpose": {"type": "query", "kind": "object", "target": "600", "view": "resource"},
  "grants": [{"kind": "object", "target": "600", "capability": "61"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-content-final.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-content-final" >"$EVIDENCE/query-content-final.stdout"
jq -e '[.cell.entries[].type] | sort == ["atom", "document", "element"]' \
  "$EVIDENCE/query-content-final/view.json" >/dev/null
jq -e '[.cell.entries[] | select(.type == "atom" and .id == "7001" and .payload == "68656c6c6f")] | length == 1' \
  "$EVIDENCE/query-content-final/view.json" >/dev/null
CONTENT_FINAL_ROOT=$(page_root "$EVIDENCE/query-content-final/view.json")
test "$CONTENT_ROOT" != "$CONTENT_FINAL_ROOT"
CONTENT_FINAL_BOUNDARY=$(challenge_field "$EVIDENCE/query-content-final/challenge.json" worldRoot)
CONTENT_FINAL_HEIGHT=$(challenge_field "$EVIDENCE/query-content-final/challenge.json" height)
test "$CONTENT_FINAL_BOUNDARY" = "$JOINT_BEFORE_RETRY_BOUNDARY"
test "$CONTENT_FINAL_HEIGHT" = "$JOINT_BEFORE_RETRY_HEIGHT"

cat >"$EVIDENCE/query-scalar-final.json" <<'EOF'
{
  "subject": "7",
  "nonce": "30009",
  "purpose": {"type": "query", "kind": "object", "target": "601", "view": "resource"},
  "grants": [{"kind": "object", "target": "601", "capability": "63"}]
}
EOF
"$MINI" query --host "$HOST" --config "$CONFIG" \
  --intent "$EVIDENCE/query-scalar-final.json" --key "$EVIDENCE/alice.key" --view resource \
  --dir "$EVIDENCE/query-scalar-final" >"$EVIDENCE/query-scalar-final.stdout"
jq -e '[.cell.entries[] | select(.key.type == "object" and .key.resource == "601" and .key.field == "0" and .value == "1")] | length == 1' \
  "$EVIDENCE/query-scalar-final/view.json" >/dev/null
SCALAR_FINAL_ROOT=$(page_root "$EVIDENCE/query-scalar-final/view.json")
test "$SCALAR_ROOT" != "$SCALAR_FINAL_ROOT"
SCALAR_FINAL_BOUNDARY=$(challenge_field "$EVIDENCE/query-scalar-final/challenge.json" worldRoot)
SCALAR_FINAL_HEIGHT=$(challenge_field "$EVIDENCE/query-scalar-final/challenge.json" height)
test "$SCALAR_FINAL_BOUNDARY" = "$JOINT_BEFORE_RETRY_BOUNDARY"
test "$SCALAR_FINAL_HEIGHT" = "$JOINT_BEFORE_RETRY_HEIGHT"

birth_transaction=$(receipt_field "$EVIDENCE/birth-attempt/outcome.json" transactionId)
content_transaction=$(receipt_field "$EVIDENCE/content-attempt/retry-0001.json" transactionId)
joint_transaction=$(receipt_field "$EVIDENCE/joint-attempt/outcome.json" transactionId)

cat >"$EVIDENCE/acceptance.json" <<EOF
{
  "status": "pass",
  "host": "$HOST",
  "semantics": "$SEMANTICS",
  "contentCallSha256": "$CALL_HASH_AFTER",
  "jointCallSha256": "$JOINT_CALL_HASH_AFTER",
  "birthTransaction": "$birth_transaction",
  "contentTransaction": "$content_transaction",
  "jointTransaction": "$joint_transaction",
  "lostOutcomeRecoveredByExactRetry": true
}
EOF
cat "$EVIDENCE/acceptance.json"
